import React, { Component } from 'react';

import axios from 'axios';

class WorldComponent extends Component {

 

    constructor(props) {

        super(props)

        this.state = {

            data: []

        }

    }

 

    componentDidMount() {

        axios.get("https://corona.lmao.ninja/v2/countries").then(response => {

 

            console.log(response);

            this.setState({ data: response.data });

            console.log(this.state);

 

        });

    }

 

    render() {

        return (

            <div className="row">

                <div className="col-md-12">

                    <table className="table table-bordered table-striped">

                        <thead>

                            <tr>

                                <td>Country Flag</td>

                                <td>Country</td>

                                <td>Total Cases</td>

                                <td>Active Cases</td>

                                <td>Recovered</td>

                                <td>Death</td>

                               

                            </tr>

 

                        </thead>

                        <tbody>

                            {

                                this.state.data.map((items, key) => {

                                    return (

                                        <tr>

                                            <td><img src={items.countryInfo.flag} width="50px;" /></td>

                                            <td>{items.country}</td>

                                            <td>{items.cases}</td>

                                            <td>{items.active}</td>

                                            <td>{items.recovered}</td>

                                            <td>{items.deaths}</td>

                                        </tr>

                                        );

                                  

 

                                })

                            }

                        </tbody>

                    </table>

                </div>

 

            </div>

 

 

        );

    }

}

 

export default WorldComponent;