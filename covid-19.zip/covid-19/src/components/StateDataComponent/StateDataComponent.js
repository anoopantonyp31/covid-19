import React, { Component } from 'react';

import axios from 'axios';

import Accordion from 'react-bootstrap/Accordion';

import Card from 'react-bootstrap/Card';

import { Button } from 'react-bootstrap';

class StateDataComponent extends Component {

 

    constructor(props) {

        super(props)

        this.state = {

            stateData: {}

        }

    }

 

    componentDidMount() {

        axios.get("https://api.covid19india.org/state_district_wise.json").then(response => {

 

            console.log(response);

            this.setState({ stateData: response.data });

            console.log(this.state);

           

        });

    }

 

    render() {

 

        let keys = Object.keys(this.state.stateData);

        return (

            <div className="row">

                <div className="col-md-12">

                    <Accordion>

                        {

                            keys.map((item, ky) => {

                               

                                let district = this.state.stateData[item].districtData;                              

                                let disctrictKeys = Object.keys(district);

                                console.log(disctrictKeys);

                                let total_active = 0;

                                let total_confirmend = 0;

                                let total_death = 0;

                                let total_recover = 0;

                                let district_list = [];

                                for (let x in district) {

                                    total_active += district[x].active;

                                    total_confirmend += district[x].confirmed;

                                    total_death += district[x].deceased;

                                    total_recover += district[x].recovered;

                                    let ob = district[x];

                                    ob["district_name"] = x;

                                    district_list.push(ob);

                                }

                                console.log(district_list);

                               

 

                                return (

                                    <Card>

                                        <Card.Header>

                                            <Accordion.Toggle as={Button} variant="primary" eventKey={ky}>

                                                {item} <span className="btn-dark p-1 m-2">Total Cases: {total_confirmend}</span>  <span className="btn-dark p-1 m-2">Active: {total_active}</span>  <span className="btn-dark p-1 m-2">Recovered: {total_recover}</span>  <span className="btn-dark p-1 m-2">Death: {total_death}</span>

                                </Accordion.Toggle>

                                        </Card.Header>

                                        <Accordion.Collapse eventKey={ky}>

                                            <Card.Body>

                                                <table className="table table-bordered table-striped">

                                                    <thead>

                                                        <tr>

                                                            <td>Discricts</td>

                                                            <td>Confirmed</td>

                                                            <td>Active</td>

                                                            <td>Recovered</td>

                                                            <td>Death</td>

                                                        </tr>

 

                                                    </thead>

                                                    <tbody>

                                                        {

                                                            district_list.map((item, key) => {

 

                                                                return (

                                                                    <tr>

                                                                        <td>{item.district_name}</td>

                                                                        <td>{item.confirmed}</td>

                                                                        <td>{item.active}</td>

                                                                        <td>{item.recovered}</td>

                                                                        <td>{item.deceased}</td>

                                                                    </tr>

                                                                    );

                                                            })

                                                        }

                                                       

                                                    </tbody>

                                                </table>

 

                                            </Card.Body>

                                        </Accordion.Collapse>

                                    </Card>

                                   

                                    

                                    );

                            })

 

 

                        }

                       

                        

                    </Accordion>

                </div>

 

            </div>

 

 

        );

    }

}

 

export default StateDataComponent;