import logo from './logo.svg';

import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css';

import HeaderComponent from './components/HeaderComponent/HeaderComponent';

import IndiaComponent from './components/IndiaComponent/IndiaComponent';

import WorldComponent from './components/WorldComponent/WorldComponent';

 

import {

    BrowserRouter as Router,

    Switch,

    Route,

    Link

} from "react-router-dom";

 

function App() {

  return (

      <div className="container-fluid">

          <Router>

              <HeaderComponent />

              <Switch>

                  <Route exact path="/">

                      <IndiaComponent />

                  </Route>

                  <Route path="/India">

                      <IndiaComponent/>

                  </Route>

                  <Route path="/World">

                      <WorldComponent />

                  </Route>

                  <Route path="/Home">

                      <IndiaComponent />

                  </Route>

 

              </Switch>

          </Router>

         

    </div>

  );

}

 

export default App;